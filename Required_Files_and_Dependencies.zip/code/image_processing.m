% =====================================================================
% Project : Boston Image - Image Contrast Enhancement
% File    : image_processing.m
% Purpose : Compare four contrast-adjustment techniques applied to the
%           Value (V) channel of an HSV-converted RGB image.
% =====================================================================

% Import image and convert to HSV
img = imread("boston night.jpg");
imgHSV = rgb2hsv(img);

% Separate the HSV channels
H = imgHSV(:,:,1);
S = imgHSV(:,:,2);
V = imgHSV(:,:,3);

% 1. Gamma Correction
% Adjust the Value channel using a gamma value of 1/2.
imgGamma_V = V.^(1/2);
% Recombine the HSV channels with the adjusted V channel.
imgGamma_HSV = cat(3, H, S, imgGamma_V);
% Convert the image back to RGB and scale to uint8 for display.
imgGamma = uint8(255 * hsv2rgb(imgGamma_HSV));

% 2. imadjust
% Adjust the Value channel using the imadjust function.
imgAdjust_V = imadjust(V);
% Recombine the HSV channels with the adjusted V channel.
imgAdjust_HSV = cat(3, H, S, imgAdjust_V);
% Convert the image back to RGB and scale to uint8 for display.
imgAdjust = uint8(255 * hsv2rgb(imgAdjust_HSV));

% 3. histeq
% Perform global histogram equalization on the Value channel.
imgEq_V = histeq(V);
% Recombine the HSV channels with the adjusted V channel.
imgEq_HSV = cat(3, H, S, imgEq_V);
% Convert the image back to RGB and scale to uint8 for display.
imgEq = uint8(255 * hsv2rgb(imgEq_HSV));

% 4. adapthisteq
% Apply adaptive histogram equalization to the Value channel.
imgAdapt_V = adapthisteq(V);
% Recombine the HSV channels with the adjusted V channel.
imgAdapt_HSV = cat(3, H, S, imgAdapt_V);
% Convert the image back to RGB and scale to uint8 for display.
imgAdapt = uint8(255 * hsv2rgb(imgAdapt_HSV));

% Display the images for comparison using a montage.
montage({imgGamma, imgAdjust, imgEq, imgAdapt});
% Add a title to the montage.
title('Gamma, imadjust, histeq, and adapthisteq');
