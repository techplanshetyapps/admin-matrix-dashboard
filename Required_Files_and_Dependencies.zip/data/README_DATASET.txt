DATASET DEPENDENCY
===================

Required file : boston night.jpg
Used by       : code/image_processing.m  (line: img = imread("boston night.jpg");)
Type          : RGB image (JPEG), any resolution supported by MATLAB's imread
Role          : Source image whose HSV Value channel is enhanced by four
                different contrast-adjustment techniques.

NOTE TO USER:
This image file was not included in the source material provided for
packaging (only the .m script and README.md text were supplied), so it
could not be embedded in this dependencies bundle. Before running the
project, place your own "boston night.jpg" file in this /data folder
(or update the imread() path in image_processing.m to point to your
image), otherwise the script will raise a "file not found" error at
the imread() call.

Any similarly-sized outdoor/night RGB photo can be substituted; the
script does not depend on the specific content of the image, only on
it being a valid 3-channel RGB image readable by imread().
